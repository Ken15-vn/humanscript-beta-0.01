import sys
import time

# Chào mừng bro đến với lõi của HumanScript Beta 0.01
def run_humanscript(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            if not line: continue
            
            # Lệnh write: in chữ ra màn hình
            if line.startswith("write "):
                content = line[6:]
                print(eval(content))
                
            # Lệnh wait: tạm dừng chương trình (dành cho con người!)
            elif line.startswith("wait "):
                seconds = float(line[5:])
                time.sleep(seconds)
                
    except Exception as e:
        print(f"Lỗi rồi bro ơi: {e}")

if __name__ == "__main__":
    # File này sẽ chạy file test.human mà bro tạo sau đây
    run_humanscript("test.human")